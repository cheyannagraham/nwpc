nwpconverter.exe is the application. There is no user interface.
add the .csv files you want to convert to the "files" folder. then run the .exe file.
The output is the NWData.csv. 

2 assumptions were made to extract the house number and the apartment number from the data. 
The first assumption is that the house or building number is always the 1st part of the address in the address_line1 field. The second assumption is that the apartment number (if exists) is always preceded by "Apt". In any case where these are not so, the data may not output the correct information. 

This is a MVP for your testing purposes. Not a final product. Send me your feedback. 
cheyanna.graham@gmail.com

!!! IMPORTANT !!!
This is an unsigned executable. Your virus protector may flag it and refuse to let it run. Adding it as an exception should overcome that problem. 